import greenfoot.*;

/**
 * Write a description of class STORM here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class STORM extends Actor
{//10
    /**
     * Act - do whatever the STORM wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {//20
        {//50
          if (Greenfoot.isKeyDown ("down"))
        {move(-4); }
         if (Greenfoot.isKeyDown ("up"))
        {move(4); }
         if (Greenfoot.isKeyDown ("right"))
         { turn(3);}
         if (Greenfoot.isKeyDown ("left"))
         { turn(-3); }    
        }//51
        }//20
        {//40 

            }//41      
          {//30    
        GreenfootImage image = getImage();  
        image.scale(30, 30);
        setImage(image);
    }//31
    }//21    

