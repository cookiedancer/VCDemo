import greenfoot.*;  // (Actor, World, Greenfoot, GreenfootImage)

public class CrabWorld extends World
{
    /**
     * Create the crab world (the beach). Our world has a size 
     * of 560x560 cells, where every cell is just 1 pixel.
     */
    public CrabWorld() 
    {
        super(560, 560, 1);
        //add a crab to a static location using the addObject method
        // the new keyword creates a "crab or worm object"
        addObject (new Crab(), 200,200);
        //add a worm to a random location using the getRandomNumber method
        //as a parameter to the addObject method
        addObject(new worm(),
     
        Greenfoot.getRandomNumber(560), Greenfoot.getRandomNumber(560));
       
    }
}
