import greenfoot.*;

/**
 * Write a description of class Lobster here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Lobster extends Actor
{
       private int niceMeme; //storage for Random Number
    /**
     * Act - do whatever the lobster wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
public void act() 
{
    

   

    turnAtEdge();
    randomTurn();
    move(5);    
    seekForCrab();
}

 public int seeIAmError()
{
    niceMeme = Greenfoot.getRandomNumber(100);
    return niceMeme;
}

public void moveIt()
{// start method
    move(20);
}// end method
public void seekForCrab()
{
    if (isTouching(Crab.class))
    {
        removeTouching(Crab.class);
        Greenfoot.playSound("slurp.wav");
        World myCurrentWorld=getWorld();
        myCurrentWorld.addObject(new Crab(),
          Greenfoot.getRandomNumber(560),
          Greenfoot.getRandomNumber(560));
    }   
}
public void turnAtEdge()
{ if ( isAtEdge() ) 
    {
            turn(17);
            
    }
}
public void randomTurn()
{
     if ( Greenfoot.getRandomNumber(100) < 10 ) 
    {
            turn( Greenfoot.getRandomNumber(90)-45 );
    }
}
}
