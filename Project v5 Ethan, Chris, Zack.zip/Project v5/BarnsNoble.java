import greenfoot.*;

/**
 * Write a description of class BarnsNoble here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BarnsNoble extends Vbsc
{

    /**
     * Constructor for objects of class BarnsNoble.
     * 
     */
    public BarnsNoble()
    {addObject (new BNhours(),842,532);
    }
}
