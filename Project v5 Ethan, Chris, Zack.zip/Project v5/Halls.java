import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Halls here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Halls extends Hat
{

    /**
     * Constructor for objects of class Halls.
     * 
     */
    public Halls()
    {
    }
}
