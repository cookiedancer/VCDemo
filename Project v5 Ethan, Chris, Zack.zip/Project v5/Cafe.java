import greenfoot.*;

/**
 * Write a description of class Cafe here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Cafe extends Vbsc
{

    /**
     * Constructor for objects of class Cafe.
     * 
     */
    public Cafe()
    {addObject (new CafeMenu(),746,320);
    }
}
