import greenfoot.*;

/**
 * Write a description of class CafeMenu here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CafeMenu extends Boards
{
    /**
     * Act - do whatever the CafeMenu wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        {//30    
        GreenfootImage image = getImage();  
        image.scale(450,638);
        setImage(image);
    }//31
    }    
}
