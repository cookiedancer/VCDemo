import greenfoot.*;

/**
 * Write a description of class Fitness here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class fitness extends Vbsc
{ 
    public fitness ()
    {addObject (new FitDailyMenu(),746,320); 
    }
}