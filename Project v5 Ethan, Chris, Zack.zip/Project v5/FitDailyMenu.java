import greenfoot.*;

/**
 * Write a description of class FitDailyMenu here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FitDailyMenu extends Boards
{
    /**
     * Act - do whatever the FitDailyMenu wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
