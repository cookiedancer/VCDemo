import greenfoot.*;

/**
 * Write a description of class Hat here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Hat extends World
{

    /**
     * Constructor for objects of class Hat.
     * 
     */
    public Hat()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(970, 690, 1); 
    }
}
