import greenfoot.*;
public class TurnArrowKeys
{
    Actor myObject;
    
    public TurnArrowKeys(Actor anObject)
    {
        myObject = anObject;
    }
    
    public void controlArrowKeys()
    {
       
        }
    }

