import greenfoot.*;

/**
 * Write a description of class TaskBar here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TaskBar extends Actor
{
    /**
     * Act - do whatever the TaskBar wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    } 
    {//30    
        GreenfootImage image = getImage();  
        image.scale(980, 50);
        setImage(image);//sets size
    }//31 
}
